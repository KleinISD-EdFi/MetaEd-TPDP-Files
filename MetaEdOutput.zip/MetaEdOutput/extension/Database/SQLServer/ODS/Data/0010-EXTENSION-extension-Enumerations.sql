INSERT INTO [extension].[FederalLocaleCodeType] ([CodeValue], [Description], [ShortDescription]) VALUES ('', 'City', 'City')
GO
INSERT INTO [extension].[FederalLocaleCodeType] ([CodeValue], [Description], [ShortDescription]) VALUES ('', 'Other', 'Other')
GO
INSERT INTO [extension].[FederalLocaleCodeType] ([CodeValue], [Description], [ShortDescription]) VALUES ('', 'Rural', 'Rural')
GO
INSERT INTO [extension].[FederalLocaleCodeType] ([CodeValue], [Description], [ShortDescription]) VALUES ('', 'Suburb', 'Suburb')
GO
INSERT INTO [extension].[FederalLocaleCodeType] ([CodeValue], [Description], [ShortDescription]) VALUES ('', 'Town', 'Town')
GO
